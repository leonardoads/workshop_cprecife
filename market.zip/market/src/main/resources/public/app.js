'use strict';

// Declare app level module which depends on views, and components
angular.module('poc', [
    'ngRoute', 'ngResource',
    'smart-table',
    'poc.client',
    'poc.home',
    'poc.product',
    'poc.sell',
    'poc.service'
])
    .config(function ($routeProvider) {
        $routeProvider.otherwise({redirectTo: '/home'});
    });
