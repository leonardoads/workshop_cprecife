(function () {
    'use strict';

    angular.module('poc.sell', ['ngRoute'])

        .config(['$routeProvider', function ($routeProvider) {
            $routeProvider
                .when('/sell', {
                    templateUrl: 'app/components/sell/sellView.html',
                    controller: 'CreateSellCtrl'
                });
        }]);
})();