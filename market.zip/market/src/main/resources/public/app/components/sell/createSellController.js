(function () {
    'use strict';

    angular
        .module('poc.sell')
        .controller('CreateSellCtrl', CreateSellCtrl);

    CreateSellCtrl.$inject = ['$scope', "ApiService"];

    /* @ngInject */
    function CreateSellCtrl($scope, ApiService) {
        $scope.sell = {};
        $scope.sell.productSet = [];

        ApiService.getClients().then(getClients);
        function getClients(result) {
            $scope.clients = result.data;
        }

        ApiService.getProducts().then(getProducts);
        function getProducts(result) {
            $scope.products = result.data;
        }

        $scope.addProduct = function () {
            if (typeof $scope.sell.productSet === "undefined") {
                $scope.sell.productSet = [];
            }
            $scope.sell.productSet.push($scope.sell.product);
        };

        $scope.submit = function () {
            $scope.sell.sellId = Date.now();

            ApiService.createSell($scope.sell).then(success, error);

            function success() {
                $scope.sell = {};
            }

            function error(result) {
                $scope.errorMessage = "Sorry Occurred a Error. Please Try again";
            }
        };
    }
})();
