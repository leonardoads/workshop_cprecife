(function () {
    'use strict';

    angular
        .module('poc.client')
        .controller('CreateClientCtrl', CreateClientCtrl);

    CreateClientCtrl.$inject = ['$scope', 'ApiService'];

    /* @ngInject */
    function CreateClientCtrl($scope, ApiService) {
        $scope.client = {};

        $scope.submit = function () {
            console.log($scope.client)
            $scope.client.id = Date.now()
            ApiService.createClient($scope.client).then(sucess, error)

            function sucess() {
                delete $scope.client;
            }

            function error(result) {
                $scope.errorMessage = "Sorry Ocurred a Error. Please Try again"
                console.log(result.data)
            }
        };
    }
})();
