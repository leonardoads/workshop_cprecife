(function () {
    'use strict';

    angular
        .module('poc.product')
        .controller('CreateProductCtrl', CreateProductCtrl);

    CreateProductCtrl.$inject = ['$scope', 'ApiService'];

    /* @ngInject */
    function CreateProductCtrl($scope, ApiService) {
        $scope.product = {};

        $scope.submit = function () {
            console.log($scope.product)
            $scope.product.id = Date.now()
            ApiService.createProduct($scope.product).then(sucess, error)

            function sucess() {
                $scope.product = {}
            }

            function error(result) {
                $scope.errorMessage = "Sorry Ocurred a Error. Please Try again"
                console.log(result.data)
            }
        };
    }
})();
