(function () {
    'use strict';

    angular.module('poc.client', ['ngRoute'])

        .config(['$routeProvider', function ($routeProvider) {
            $routeProvider
                .when('/client', {
                    templateUrl: 'app/components/client/clientView.html',
                    controller: 'CreateClientCtrl'
                });
        }]);
})();
