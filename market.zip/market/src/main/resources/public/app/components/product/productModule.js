(function () {
    'use strict';

    angular.module('poc.product', ['ngRoute'])

        .config(['$routeProvider', function ($routeProvider) {
            $routeProvider
                .when('/product', {
                    templateUrl: 'app/components/product/productView.html',
                    controller: 'CreateProductCtrl'
                });
        }])
})();