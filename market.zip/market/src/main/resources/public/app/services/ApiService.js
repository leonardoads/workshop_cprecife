(function () {
    'use strict';

    angular.module('poc.service', [])
        .service('ApiService', ApiService);

    ApiService.$inject = ['$http'];

    /* @ngInject */
    function ApiService($http) {
        //constants
        var ENDPOINT_URI = 'http://localhost:8083/api/1.0/';

        var CLIENT_URI = ENDPOINT_URI + 'client/';

        var PRODUCT_URI = ENDPOINT_URI + 'product/';

        var SELL_URI = ENDPOINT_URI + 'sell';

        //private methods

        //Client Service
        function getClients() {
            return $http.get(CLIENT_URI)
        }

        function createClient(client) {
            return $http.post(CLIENT_URI, client);
        }

        function getClient(clientId) {
            return $http.get(CLIENT_URI + clientId)
        }

        function deleteClient(clientId) {

        }

        //Product Service
        function getProducts() {
            return $http.get(PRODUCT_URI)
        }

        function createProduct(product) {
            return $http.post(PRODUCT_URI, product);
        }

        function getProduct(productId) {
            return $http.get(PRODUCT_URI + productId)
        }

        function deleteProduct(productId) {

        }

        //sell services
        function getSells() {
            return $http.get(SELL_URI)
        }

        function createSell(sell) {
            return $http.post(SELL_URI, sell);
        }

        function getSell(sellId) {
            return $http.get(SELL_URI + sellId)
        }

        function deleteSell(sellId) {

        }


        //Public methods
        this.getClients = getClients;
        this.getClient = getClient;
        this.createClient = createClient;
        this.deleteClient = deleteClient;
        this.getProducts = getProducts;
        this.getProduct = getProduct;
        this.createProduct = createProduct;
        this.deleteProduct = deleteProduct;
        this.getSells = getSells;
        this.getSell = getSell;
        this.createSell = createSell;
        this.deleteSell = deleteSell;


    }
})();