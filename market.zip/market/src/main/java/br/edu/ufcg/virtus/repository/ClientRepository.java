package br.edu.ufcg.virtus.repository;


import br.edu.ufcg.virtus.domain.Client;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ClientRepository extends MongoRepository<Client, Long> {
}
