package br.edu.ufcg.virtus.service.sell;

import br.edu.ufcg.virtus.domain.Sell;

import java.util.List;

/**
 * @author LeonardoAlvesdosSant.
 */
public interface SellService {
    /**
     * @param sell The sell object who you intends save at the Database.
     * @return The Sell Saved
     */
    Sell save(Sell sell);


    /**
     * Obtain a sell using it ID.
     *
     * @param id The primary key of the sell who intends get.
     * @return The sell with the id specified
     */
    Sell getById(long id);

    /**
     * Obtain a list with all Sells ordered by Id.
     *
     * @return A List with all Sells registered.
     */
    List<Sell> getAll();

    /**
     *
     * @param id Id is the primary key of the sell who intends delete.
     */
    void delete(long id);
}
