package br.edu.ufcg.virtus.controller;

import br.edu.ufcg.virtus.domain.Product;
import br.edu.ufcg.virtus.service.product.ProductService;
import br.edu.ufcg.virtus.service.product.exceptions.ProductNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Leonardo Alves dos Santos.
 */
@RestController
public class ProductController {
    /**
     *
     */
    private final ProductService service;

    /**
     *
     * @param service .
     */
    @Autowired
    public ProductController(ProductService service) {
        this.service = service;
    }

    /**
     *
     * @return .
     */
    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/product", method = RequestMethod.GET)
    public ResponseEntity<List<Product>> listAllClient() {
        return new ResponseEntity<>(
                service.getAll(), HttpStatus.OK);
    }

    /***
     *
     * @param product .
     * @return .
     */
    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/product", method = RequestMethod.POST)
    public ResponseEntity<String> createProduct(@RequestBody Product product) {
        try {
            service.save(product);
            return new ResponseEntity<>(HttpStatus.CREATED);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    /**
     *
     * @param id .
     * @return .
     */
    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/product/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<String> deleteClient(@PathVariable long id){
        try {
            service.delete(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }catch (ProductNotFoundException e){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }catch (Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @param id .
     * @return .
     */
    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/product/{id}", method = RequestMethod.GET)
    public ResponseEntity<Product> getClientByName(@PathVariable long id) {
        Product product = service.getById(id);

        return (product == null) ?
                new ResponseEntity<>(HttpStatus.NOT_FOUND)
                : new ResponseEntity<>(product, HttpStatus.OK);
    }


}
