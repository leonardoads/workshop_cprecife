package br.edu.ufcg.virtus.service.product;

import br.edu.ufcg.virtus.domain.Product;

import java.util.List;

/**
 * @author Leonardo Alves dos Santos.
 *
 * This interface provide the Services who can used with the Product at Controller.
 */
public interface ProductService {
    /**
     * @param product The product object who you intends save at the Database.
     * @return The Product Saved
     */
    Product save(Product product);


    /**
     * Obtain a product using it ID.
     *
     * @param id The primary key of the product who intends get.
     * @return The product with the id specified
     */
    Product getById(long id);

    /**
     * Obtain a list with all Products ordered by Id.
     *
     * @return A List with all Products registered.
     */
    List<Product> getAll();

    /**
     *
     * @param id Id is the primary key of the product who intends delete.
     */
    void delete(long id);
}
