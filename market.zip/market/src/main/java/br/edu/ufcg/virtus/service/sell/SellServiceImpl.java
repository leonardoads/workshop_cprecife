package br.edu.ufcg.virtus.service.sell;

import br.edu.ufcg.virtus.domain.Sell;
import br.edu.ufcg.virtus.repository.SellRepository;
import br.edu.ufcg.virtus.service.sell.exceptions.SellNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author LeonardoAlvesdosSant.
 */

@Service
@Validated
public class SellServiceImpl implements  SellService {

    @Autowired
    private SellRepository repository;


    @Transactional
    public Sell save(@NotNull @Valid Sell sell) {
        return repository.save(sell);
    }


    public Sell getById(long id) {
        return repository.findOne(id);
    }

    public List<Sell> getAll() {
        return repository.findAll();
    }

    @Transactional
    public void delete(long id) {
        Sell client = repository.findOne(id);
        if ( client == null ) {
            throw new SellNotFoundException("Sell Not Exists");
        }else{
            repository.delete(id);
        }
    }

    public SellRepository getRepository() {
        return repository;
    }

      public void setRepository(SellRepository repository) {

        this.repository = repository;
    }
}
