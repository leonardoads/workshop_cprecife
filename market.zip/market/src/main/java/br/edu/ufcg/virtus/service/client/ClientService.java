package br.edu.ufcg.virtus.service.client;
import br.edu.ufcg.virtus.domain.Client;
import br.edu.ufcg.virtus.service.client.exceptions.ClientAlreadyExistsException;

import java.util.List;

/**
 * @author leonardo
 */
public interface ClientService {
    /**
     * @param client .
     * @return
     */
    Client save(Client client) throws ClientAlreadyExistsException;


    /**
     * @param id .
     * @return
     */
    Client getById(long id);

    /**
     *
     * @param name .
     * @return .
     */
    List<Client> getByName(String name);

    /**
     *
     * @param cpf .
     * @return .
     */
    Client getByCPF(String cpf);

    /**
     * @return
     */
    List<Client> getAll();

    void delete(long id);
}
