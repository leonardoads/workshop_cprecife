/**
 *
 */
package br.edu.ufcg.virtus.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * @author leonardo
 */

public class Client implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -1310504687165875319L;

    private long id;

    private String name;
    private String address;
    private Date bornDate;
    private char sex;
    private String cpf;
    public Client() {
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getBornDate() {
        return bornDate;
    }

    public void setBornDate(Date bornDate) {
        this.bornDate = bornDate;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }
}
