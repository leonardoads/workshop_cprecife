package br.edu.ufcg.virtus.controller;

import br.edu.ufcg.virtus.domain.Sell;
import br.edu.ufcg.virtus.service.sell.SellService;
import br.edu.ufcg.virtus.service.sell.exceptions.SellNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author LeonardoAlvesdosSant.
 */
@RestController
public class SellController {
    /**
     *
     */
    private final SellService service;

    @Autowired
    public SellController(SellService sellService) {
        this.service = sellService;
    }

    /**
     *
     * @return .
     */
    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/sell", method = RequestMethod.GET)
    public ResponseEntity<List<Sell>> listAllClient() {
        return new ResponseEntity<>(
                service.getAll(), HttpStatus.OK);
    }

    /***
     *
     * @param sell .
     * @return .
     */
    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/sell", method = RequestMethod.POST)
    public ResponseEntity<String> createSell(@RequestBody Sell sell) {
        try {
            service.save(sell);
            return new ResponseEntity<>(HttpStatus.CREATED);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    /**
     *
     * @param id .
     * @return .
     */
    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/sell/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<String> deleteClient(@PathVariable long id){
        try {
            service.delete(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }catch (SellNotFoundException e){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }catch (Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @param id .
     * @return .
     */
    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/sell/{id}", method = RequestMethod.GET)
    public ResponseEntity<Sell> getClientByName(@PathVariable long id) {
        Sell sell = service.getById(id);

        return (sell == null) ?
                new ResponseEntity<>(HttpStatus.NOT_FOUND)
                : new ResponseEntity<>(sell, HttpStatus.OK);
    }


}
