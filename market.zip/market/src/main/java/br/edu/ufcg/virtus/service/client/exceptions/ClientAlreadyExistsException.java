package br.edu.ufcg.virtus.service.client.exceptions;

public class ClientAlreadyExistsException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = -8473990752632941843L;

    public ClientAlreadyExistsException(final String message) {
        super(message);
    }
}
