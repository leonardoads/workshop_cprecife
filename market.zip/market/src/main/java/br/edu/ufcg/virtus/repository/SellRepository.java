package br.edu.ufcg.virtus.repository;

import br.edu.ufcg.virtus.domain.Sell;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * @author LeonardoAlvesdosSant.
 */
public interface SellRepository extends MongoRepository<Sell, Long> {
}
