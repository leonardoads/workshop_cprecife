package br.edu.ufcg.virtus.service.product.exceptions;

/**
 * Created by LeonardoAlvesdosSant on 14/07/2016.
 */
public class ProductNotFoundException extends RuntimeException {
    public ProductNotFoundException(String message) {
        super(message);
    }
}
