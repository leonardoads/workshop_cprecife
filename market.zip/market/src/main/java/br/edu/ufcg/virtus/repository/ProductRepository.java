package br.edu.ufcg.virtus.repository;

import br.edu.ufcg.virtus.domain.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * Created by LeonardoAlvesdosSant on 14/07/2016.
 */
public interface ProductRepository  extends MongoRepository<Product, Long> {
}
