package br.edu.ufcg.virtus.service.sell.exceptions;

/**
 * @author LeonardoAlvesdosSant.
 */
public class SellNotFoundException extends RuntimeException{
    public SellNotFoundException(String message) {
    }
}
