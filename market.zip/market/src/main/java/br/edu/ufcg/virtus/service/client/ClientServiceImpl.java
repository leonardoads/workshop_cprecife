package br.edu.ufcg.virtus.service.client;

import br.edu.ufcg.virtus.domain.Client;
import br.edu.ufcg.virtus.repository.ClientRepository;
import br.edu.ufcg.virtus.service.client.exceptions.ClientAlreadyExistsException;
import br.edu.ufcg.virtus.service.client.exceptions.ClientNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.transaction.Transactional;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Service
@Validated
public class ClientServiceImpl implements ClientService {

    private final ClientRepository repository;

    /**
     * @param repository
     */
    @Autowired
    public ClientServiceImpl(final ClientRepository repository) {
        this.repository = repository;
    }

    /**
     * @return
     */
    public ClientRepository getRepository() {
        return repository;
    }

    /**
     *
     */
    @Transactional
    public Client save(@NotNull @Valid Client client) throws ClientAlreadyExistsException {
        Client existing = repository.findOne(client.getId());

        if (existing != null) {
            throw new ClientAlreadyExistsException(String.format("There already exists a participant with name=%s", client.getName()));
        }

        return repository.save(client);
    }




    @Override
    public void delete(long id) {
        Client client = repository.findOne(id);
        if ( client == null ) {
            throw new ClientNotFoundException("Client Not Exists");
        }else{
            repository.delete(id);
        }
    }

    /**
     *
     */
    public Client getById(long id) {
        return repository.findOne(id);
    }

    /**
     *
     * @param name .
     * @return .
     */
    public List<Client> getByName(String name) {
        List<Client> clientsByName = new ArrayList<>();
        for (Client client: this.getAll()) {
            if (client.getName().contains(name)){
                clientsByName.add(client);
            }
        }
        return clientsByName;
    }

    /**
     *
     * @param cpf .
     * @return .
     */
    public Client getByCPF(String cpf) {
        Client clientOut = null;
        for (Client client: this.getAll()) {
            if (client.getCpf().equals(cpf)){
                clientOut = client;
                break;
            }
        }

        return clientOut;
    }


    public List<Client> getAll() {
        return repository.findAll();
    }

}
