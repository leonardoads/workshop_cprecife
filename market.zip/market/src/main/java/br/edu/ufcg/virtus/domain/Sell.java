package br.edu.ufcg.virtus.domain;

import java.io.Serializable;
import java.util.List;

/**
 * @author LeonardoAlvesdosSant.
 */
public class Sell  implements Serializable {

    private static final long serialVersionUID = -1310504687165875319L;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    private long sellId;

    private List<Product> productSet;

    private String clientId;

    public Sell() {
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public long getSellId() {
        return sellId;
    }

    public void setSellId(long sellId) {
        this.sellId = sellId;
    }

    public List<Product> getProductSet() {
        return productSet;
    }

    public void setProductSet(List<Product> productSet) {
        this.productSet = productSet;
    }
}
