package br.edu.ufcg.virtus.service.product;

import br.edu.ufcg.virtus.domain.Product;
import br.edu.ufcg.virtus.repository.ProductRepository;
import br.edu.ufcg.virtus.service.product.exceptions.ProductNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author Leonardo Alves dos Santos.
 */
@Service
@Validated
public class ProductServiceImpl implements ProductService {

    private final ProductRepository repository;

    public ProductRepository getRepository() {
        return repository;
    }

    @Autowired
    public ProductServiceImpl(ProductRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public Product save(@NotNull @Valid Product product) {
        return repository.save(product);
    }


    public Product getById(long id) {
        return repository.findOne(id);
    }

    public List<Product> getAll() {
        return repository.findAll();
    }

    @Transactional
    public void delete(long id) {
        Product client = repository.findOne(id);
        if ( client == null ) {
            throw new ProductNotFoundException("Product Not Exists");
        }else{
            repository.delete(id);
        }
    }
}
