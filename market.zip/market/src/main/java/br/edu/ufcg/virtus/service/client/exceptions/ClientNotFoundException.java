package br.edu.ufcg.virtus.service.client.exceptions;

/**
 * Created by leonardo on 13/07/16.
 */
public class ClientNotFoundException extends RuntimeException {
    public ClientNotFoundException(String message) {
    }
}
