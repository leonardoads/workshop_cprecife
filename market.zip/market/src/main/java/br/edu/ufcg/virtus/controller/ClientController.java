/**
 *.
 */
package br.edu.ufcg.virtus.controller;


import br.edu.ufcg.virtus.domain.Client;
import br.edu.ufcg.virtus.service.client.ClientService;
import br.edu.ufcg.virtus.service.client.exceptions.ClientAlreadyExistsException;
import br.edu.ufcg.virtus.service.client.exceptions.ClientNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author leonardo
 */
@RestController
public class ClientController {
    /**
     *
     */
    private final ClientService service;

    @Autowired
    public ClientController(ClientService service) {
        this.service = service;
    }

    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/client", method = RequestMethod.GET)
    public ResponseEntity<List<Client>> listAllClient() {
        return new ResponseEntity<>(
                service.getAll(), HttpStatus.OK);
    }

    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/client", method = RequestMethod.POST)
    public ResponseEntity<String> createClient(@RequestBody Client client) {

        try {
            service.save(client);
            return new ResponseEntity<>(HttpStatus.CREATED);
        } catch (ClientAlreadyExistsException e) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/client/{id}", method = RequestMethod.GET)
    public ResponseEntity<Client> getClientById(@PathVariable long id) {
        Client client = service.getById(id);
        return (client == null) ?
                new ResponseEntity<>(HttpStatus.NOT_FOUND)
                : new ResponseEntity<>(client, HttpStatus.OK);
    }

    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/client/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<String> deleteClient(@PathVariable long id) {
        try {
            service.delete(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }catch (ClientNotFoundException e){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }catch (Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/client/cpf/{cpf}", method = RequestMethod.GET)
    public ResponseEntity<Client> getClientByCPF(@PathVariable String cpf){
        Client client = service.getByCPF(cpf);

        return (client == null) ?
                new ResponseEntity<>(HttpStatus.NOT_FOUND)
                : new ResponseEntity<>(client, HttpStatus.OK);
    }

    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(value = "api/1.0/client/name/{name}", method = RequestMethod.GET)
    public ResponseEntity< List<Client>> getClientByName(@PathVariable String name){
        return new ResponseEntity<>(service.getByName(name), HttpStatus.OK);
    }
}
